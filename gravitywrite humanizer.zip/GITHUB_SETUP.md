# GitHub Setup Guide

Quick guide to push this Claude skill to GitHub and use it across your projects.

## Initial Setup

### 1. Create GitHub Repository

```bash
# Navigate to the skill folder
cd human-ghostwriter-skill

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Human Ghostwriter Claude Skill v1.0"

# Create repository on GitHub (via web UI or CLI)
# Then link it:
git remote add origin https://github.com/YOUR-USERNAME/human-ghostwriter-skill.git

# Push
git branch -M main
git push -u origin main
```

### 2. Add Repository Description

On GitHub, add this description:
```
🤖➡️👤 Professional AI content humanizer for Claude. Rewrites AI-generated text to bypass detection tools (GPTZero, Originality.ai, Turnitin) while preserving meaning and quality.
```

### 3. Add Topics/Tags

Recommended tags:
- `claude-ai`
- `claude-skills`
- `ai-detection`
- `content-humanizer`
- `ai-writing`
- `ghostwriting`
- `content-rewriting`
- `ai-bypass`

## File Structure

Your repository should look like this:

```
human-ghostwriter-skill/
├── SKILL.md           # Main skill file for Claude
├── README.md          # Documentation
├── EXAMPLES.md        # Before/after examples
├── LICENSE            # MIT License
├── .gitignore         # Git ignore rules
└── GITHUB_SETUP.md    # This file
```

## Using This Skill in Claude

### Option 1: Direct Upload
1. Go to claude.ai
2. Click **Skills** in sidebar
3. Click **Add Skill** → **Upload Skill**
4. Upload `SKILL.md`

### Option 2: GitHub Integration
1. In claude.ai, go to **Skills**
2. Click **Add Skill** → **From GitHub**
3. Paste your repository URL
4. Claude will auto-import the skill

## Updating the Skill

When you make improvements:

```bash
# Make your changes to SKILL.md or other files

# Stage changes
git add .

# Commit with descriptive message
git commit -m "feat: Added support for technical documentation tone"

# Push to GitHub
git push
```

If using GitHub integration in Claude, it will auto-update. If using direct upload, re-upload the updated `SKILL.md`.

## Version Management

Update version numbers in:
- `SKILL.md` (bottom of file)
- `README.md` (footer section)

Use semantic versioning:
- `1.0.0` → `1.0.1` for bug fixes
- `1.0.0` → `1.1.0` for new features
- `1.0.0` → `2.0.0` for breaking changes

## Sharing Your Skill

### Make it Public
1. Ensure repository is **Public** on GitHub
2. Add comprehensive README
3. Include examples
4. Add license

### Promote
- Share on Twitter/X with `#ClaudeSkills`
- Post in Claude community forums
- Add to awesome-claude-skills lists
- Include in your portfolio

## Contributing

If others want to contribute:

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-tone-mode`
3. Make changes
4. Commit: `git commit -m "Add casual tone mode"`
5. Push: `git push origin feature/new-tone-mode`
6. Create Pull Request on GitHub

## Backup Strategy

This skill is now safely stored on GitHub. To use it anywhere:

```bash
# Clone to any machine
git clone https://github.com/YOUR-USERNAME/human-ghostwriter-skill.git

# Or download as ZIP from GitHub web interface
```

## Troubleshooting

**Skill not appearing in Claude?**
- Check that `SKILL.md` is at the root of your repository
- Verify the file is named exactly `SKILL.md` (case-sensitive)
- Ensure GitHub repository is accessible

**Changes not reflecting in Claude?**
- If using GitHub integration, wait a few minutes for sync
- If using direct upload, re-upload the file manually

**Want to create multiple versions?**
- Use git branches: `git checkout -b experimental`
- Test changes before merging to main

---

**Next Steps:**
1. Push to GitHub ✓
2. Test in Claude ✓
3. Share with community ✓
4. Iterate and improve ✓

Happy humanizing! 🚀
