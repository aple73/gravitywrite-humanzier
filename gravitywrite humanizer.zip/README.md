# Human Ghostwriter Claude Skill

A professional AI content humanization skill for Claude that rewrites any text to bypass AI detection tools while maintaining meaning, tone, and quality.

## What This Skill Does

Transforms AI-generated or robotic-sounding content into natural, human-written prose that:
- ✅ Passes GPTZero, Originality.ai, Turnitin, Winston AI, Copyleaks
- ✅ Reads authentically human
- ✅ Preserves all original information and intent
- ✅ Matches any writing style (academic, casual, technical, marketing)

## Installation

### Option 1: Direct Upload to Claude.ai
1. Download the `SKILL.md` file
2. Go to claude.ai
3. Click the **Skills** icon in the sidebar
4. Click **Add Skill** → **Upload Skill**
5. Select `SKILL.md`

### Option 2: GitHub Integration
1. Fork or clone this repository
2. Push to your GitHub account
3. In claude.ai, go to **Skills** → **Add Skill** → **From GitHub**
4. Connect your repository

### Option 3: Copy-Paste
1. Open `SKILL.md`
2. Copy all contents
3. In claude.ai, create a new skill and paste the content

## Usage

Once installed, the skill activates automatically when you use trigger phrases:

### Basic Usage
```
Humanize this text:

[paste your AI-generated content here]
```

### Alternative Triggers
- "Make this undetectable"
- "Rewrite to sound human"
- "Bypass AI detection for this"
- "Remove AI patterns from this"
- "Sound more natural"

## Features

### Core Techniques Applied

1. **Burstiness** - Dramatic sentence length variation (3-35 words)
2. **Perplexity** - Unexpected but appropriate word choices
3. **Active Voice** - Eliminates passive constructions
4. **Idioms & Colloquialisms** - Natural conversational phrases
5. **Personal Perspective** - Subtle human voice and observations
6. **Syntax Variety** - Different sentence structures and starters
7. **AI Pattern Removal** - Eliminates triple lists, symmetrical pairs, summary sentences

### Supported Content Types

- ✅ Academic essays and research papers
- ✅ Blog posts and articles
- ✅ Marketing copy and sales pages
- ✅ Technical documentation
- ✅ Social media posts
- ✅ Business reports
- ✅ Email campaigns
- ✅ Creative writing

## Examples

### Before (AI-Generated)
> "Artificial intelligence has revolutionized multiple industries. The technology enables automation, improves efficiency, and reduces costs. Furthermore, AI systems can process vast amounts of data. Additionally, they provide insights that humans might overlook."

### After (Humanized)
> "AI's changed everything. You see it in healthcare, finance, manufacturing—pretty much anywhere you look these days. Here's what makes it powerful: machines now handle the grunt work while spitting out insights we'd probably miss on our own. They crunch through data mountains in seconds."

## Best Practices

1. **Provide full text** - The skill works best with complete paragraphs or sections
2. **Specify tone if needed** - Mention if you want formal, casual, academic, etc.
3. **Review output** - Always read the humanized version to ensure it fits your needs
4. **Iterate if necessary** - Ask for adjustments to specific sections

## Advanced Usage

### Specify Content Type
```
Humanize this academic essay:
[text]
```

### Request Specific Tone
```
Rewrite this in a casual, conversational tone and make it undetectable:
[text]
```

### Adjust Formality
```
Make this sound human but keep it professional:
[text]
```

## Troubleshooting

**Skill not triggering?**
- Use explicit trigger phrases like "humanize this" or "make this undetectable"
- Ensure the skill is activated in your Skills settings

**Output too casual/formal?**
- Specify your desired tone explicitly in your prompt
- Reference the original style: "keep the academic tone but make it human"

**Need more changes?**
- Ask for specific adjustments: "make it even more conversational"
- Request focus on specific paragraphs

## Contributing

Found a way to improve this skill? Contributions welcome!

1. Fork the repo
2. Make your changes to `SKILL.md`
3. Test thoroughly with different content types
4. Submit a pull request

## License

MIT License - Free to use, modify, and distribute

## Credits

Created for the Claude Skills ecosystem. Designed to help writers, students, marketers, and content creators produce authentic human-sounding content.

---

**Version:** 1.0  
**Maintained by:** [Your Name/Organization]  
**Last Updated:** April 2026

## Support

Issues? Questions? Feature requests?
- Open an issue on GitHub
- Tag discussions with `human-ghostwriter-skill`

---

**⚠️ Ethical Usage Note:**  
This skill is designed for legitimate use cases like improving writing quality and natural flow. Always ensure your use complies with your institution's or organization's policies on AI-assisted content.
